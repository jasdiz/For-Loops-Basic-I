for i in range(0, 151):
    print(i)
for i in range(5,1001,151):
    print(i)
for i in range(0,101):
    if i % 10 == 0:
        print("Coding Dojo")
    elif i % 5 == 0:
        print("Coding")
    else:
        print(i)
        
sum = 0 
for i in range(0,500001,2):
    sum += i
print(sum)
for i in range(2018,0,-4):
    print(i)

low = 2
high = 9
mult = 3

for i in range (low,high + 1):
    if i % mult == 0:
        print(i)
    
    